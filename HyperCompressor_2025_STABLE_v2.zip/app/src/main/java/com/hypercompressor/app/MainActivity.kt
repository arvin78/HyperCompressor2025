package com.hypercompressor.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.TransformationRequest
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var btnPick: Button
    private lateinit var btnCompress: Button
    private lateinit var btnShare: Button
    private lateinit var progress: ProgressBar
    private lateinit var txtInfo: TextView

    private var pickedUri: Uri? = null
    private var lastOutputFile: File? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            // Persist permission so we can read later even after restart
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            contentResolver.takePersistableUriPermission(uri, flags)
        } catch (_: SecurityException) {
            // Some providers do not allow persist; still try best-effort
        }
        pickedUri = uri
        lastOutputFile = null
        btnShare.isEnabled = false
        btnCompress.isEnabled = true
        progress.progress = 0
        txtInfo.text = buildInfoText(uri, null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPick = findViewById(R.id.btnPick)
        btnCompress = findViewById(R.id.btnCompress)
        btnShare = findViewById(R.id.btnShare)
        progress = findViewById(R.id.progress)
        txtInfo = findViewById(R.id.txtInfo)

        btnPick.setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }

        btnCompress.setOnClickListener {
            val uri = pickedUri
            if (uri == null) {
                Toast.makeText(this, "اول ویدئو را انتخاب کن", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startCompression(uri)
        }

        btnShare.setOnClickListener {
            val f = lastOutputFile ?: return@setOnClickListener
            shareFile(f)
        }
    }

    private fun startCompression(uri: Uri) {
        btnPick.isEnabled = false
        btnCompress.isEnabled = false
        btnShare.isEnabled = false
        progress.progress = 0
        lastOutputFile = null

        val outDir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "HyperCompressor")
        if (!outDir.exists()) outDir.mkdirs()

        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outFile = File(outDir, "HC_${ts}.mp4")

        // Conservative settings (stable on older devices): H.264 + AAC, ~2.0 Mbps.
        val videoSettings = VideoEncoderSettings.Builder()
            .setBitrate(2_000_000)
            .build()

        val encoderFactory = DefaultEncoderFactory.Builder(this)
            .setRequestedVideoEncoderSettings(videoSettings)
            .build()

        val request = TransformationRequest.Builder()
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .build()

        val transformer = Transformer.Builder(this)
            .setEncoderFactory(encoderFactory)
            .setTransformationRequest(request)
            .addListener(object : Transformer.Listener {
                override fun onTransformationCompleted(inputMediaItem: MediaItem, outputPath: String) {
                    runOnUiThread {
                        btnPick.isEnabled = true
                        btnCompress.isEnabled = true
                        lastOutputFile = outFile
                        btnShare.isEnabled = true
                        progress.progress = 100
                        txtInfo.text = buildInfoText(uri, outFile)
                        Toast.makeText(this@MainActivity, "تمام شد ✅", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onTransformationError(
                    inputMediaItem: MediaItem,
                    exception: Exception
                ) {
                    runOnUiThread {
                        btnPick.isEnabled = true
                        btnCompress.isEnabled = true
                        btnShare.isEnabled = false
                        progress.progress = 0
                        txtInfo.text = "خطا: " + (exception.message ?: exception.toString())
                        Toast.makeText(this@MainActivity, "خطا در فشرده‌سازی", Toast.LENGTH_LONG).show()
                    }
                }
            })
            .build()

        try {
            val mediaItem = MediaItem.fromUri(uri)
            transformer.startTransformation(mediaItem, outFile.absolutePath)

            // Simple progress polling
            Thread {
                val holder = Transformer.ProgressHolder()
                while (true) {
                    val state = transformer.getProgress(holder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        val p = holder.progress.coerceIn(0, 100)
                        runOnUiThread { progress.progress = p }
                    }
                    if (state == Transformer.PROGRESS_STATE_NOT_STARTED) {
                        // brief start delay
                    }
                    if (state == Transformer.PROGRESS_STATE_UNAVAILABLE) {
                        // keep going
                    }
                    // stop when finished (share enabled) or when buttons re-enabled after error
                    if (lastOutputFile != null || btnPick.isEnabled) break
                    Thread.sleep(250)
                }
            }.start()

        } catch (e: Exception) {
            btnPick.isEnabled = true
            btnCompress.isEnabled = true
            btnShare.isEnabled = false
            txtInfo.text = "خطا: " + (e.message ?: e.toString())
            Toast.makeText(this, "خطا در شروع عملیات", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareFile(file: File) {
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل"))
    }

    private fun buildInfoText(inputUri: Uri, outputFile: File?): String {
        val inputName = queryDisplayName(inputUri) ?: "input"
        val inputSize = querySizeBytes(inputUri)
        val inputSizeStr = if (inputSize != null) humanBytes(inputSize) else "نامشخص"

        val outStr = if (outputFile != null && outputFile.exists()) {
            val outSize = outputFile.length()
            val ratio = if (inputSize != null && inputSize > 0) {
                val pct = (100.0 * (1.0 - (outSize.toDouble() / inputSize.toDouble()))).coerceIn(-999.0, 999.0)
                " (کاهش: ${String.format(Locale.US, "%.1f", pct)}٪)"
            } else ""
            "\nخروجی: ${outputFile.name}\nحجم خروجی: ${humanBytes(outSize)}$ratio\nمسیر: ${outputFile.absolutePath}"
        } else {
            "\n(برای فشرده‌سازی روی «شروع فشرده‌سازی» بزن)"
        }

        return "ورودی: $inputName\nحجم ورودی: $inputSizeStr$outStr"
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun querySizeBytes(uri: Uri): Long? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val v = c.getLong(0)
                    if (v >= 0) v else null
                } else null
            }
        } catch (_: Exception) { null }
    }

    private fun humanBytes(bytes: Long): String {
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        return when {
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.2f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.US, "%.2f KB", bytes / kb)
            else -> "$bytes B"
        }
    }
}
