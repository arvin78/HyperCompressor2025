package com.hyper.compressor2025.ui

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.snackbar.Snackbar
import com.hyper.compressor2025.BuildConfig
import com.hyper.compressor2025.data.ItemState
import com.hyper.compressor2025.data.QueueItem
import com.hyper.compressor2025.data.QueueStore
import com.hyper.compressor2025.databinding.ActivityMainBinding
import com.hyper.compressor2025.util.Formatters
import com.hyper.compressor2025.util.SafUtils
import com.hyper.compressor2025.worker.BatchCompressionWorker
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var store: QueueStore
    private lateinit var adapter: QueueAdapter

    private val pickVideos =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            val items = uris.map { uri ->
                SafUtils.persistRead(this, uri)
                val name = SafUtils.displayName(this, uri)
                val size = SafUtils.sizeBytes(this, uri)
                val target = computeTarget95(size)
                QueueItem(
                    id = UUID.randomUUID().toString(),
                    uri = uri.toString(),
                    name = name,
                    inputBytes = size,
                    targetBytes = target,
                    state = ItemState.QUEUED,
                    progress = 0,
                    outputPath = null,
                    outputBytes = null,
                    error = null
                )
            }
            store.addItems(items)
            BatchCompressionWorker.ensureRunning(this)
        }

    private val requestNotifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        refreshUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        store = QueueStore(this)
        adapter = QueueAdapter { openOutput(it) }
        binding.recycler.adapter = adapter

        binding.fab.setOnClickListener {
            maybeRequestNotifications()
            pickVideos.launch(arrayOf("video/*"))
        }

        store.registerListener(prefListener)
        refreshUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        store.unregisterListener(prefListener)
    }

    private fun refreshUi() {
        val snap = store.load()
        val items = snap.items

        binding.emptyState.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        adapter.submitList(items)

        if (items.isEmpty()) {
            binding.batchSubtitle.text = "—"
            binding.batchProgress.setProgressCompat(0, true)
            return
        }

        val sum = items.sumOf { it.progress.coerceIn(0, 100) }
        val pct = (sum.toDouble() / items.size.toDouble()).toInt().coerceIn(0, 100)

        val done = items.count { it.state == ItemState.DONE || it.state == ItemState.FAILED || it.state == ItemState.SKIPPED }
        val running = items.count { it.state == ItemState.RUNNING }
        val queued = items.count { it.state == ItemState.QUEUED }

        binding.batchProgress.setProgressCompat(pct, true)
        binding.batchSubtitle.text = "Total " + Formatters.pct(pct) + " • " + done + "/" + items.size + " done • " + running + " running • " + queued + " queued"
    }

    private fun openOutput(item: QueueItem) {
        val path = item.outputPath ?: return
        val file = File(path)
        if (!file.exists()) {
            Snackbar.make(binding.root, "فایل خروجی پیدا نشد", Snackbar.LENGTH_LONG).show()
            return
        }
        val authority = BuildConfig.APPLICATION_ID + ".fileprovider"
        val uri = FileProvider.getUriForFile(this, authority, file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "video/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching {
            startActivity(intent)
        }.onFailure {
            Snackbar.make(binding.root, "برنامه‌ای برای باز کردن ویدیو پیدا نشد", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun maybeRequestNotifications() {
        if (Build.VERSION.SDK_INT < 33) return
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) requestNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun computeTarget95(inputBytes: Long): Long {
        if (inputBytes <= 0) return 100L * 1024L * 1024L
        val raw = (inputBytes * 0.05).toLong()
        val min = 30L * 1024L * 1024L
        val max = 500L * 1024L * 1024L
        return raw.coerceIn(min, max)
    }
}
