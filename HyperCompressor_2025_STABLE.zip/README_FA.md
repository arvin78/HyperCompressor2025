# HyperCompressor 2025 (STABLE)

این نسخه برای جلوگیری از کرش روی Android 13 ساخته شده.

## روی گوشی چه کار می‌کند؟
- با دکمه «انتخاب ویدئو» چند ویدئو را انتخاب می‌کنی
- پریست را انتخاب می‌کنی (Fast / Balanced / Smallest)
- «شروع فشرده‌سازی» را می‌زنی
- خروجی‌ها در مسیر زیر ذخیره می‌شوند:

`Gallery -> Movies -> HyperCompressor` (یا مسیر: `Movies/HyperCompressor/`)

اگر باز هم کرش/خطا دیدی:
- یک فایل خطا داخل **Downloads/HyperCompressor/** ساخته می‌شود (hc_last_error_*.txt) و می‌توانی همان را بفرستی.

## نکته‌ها
- این نسخه هیچ `FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING` استفاده نمی‌کند (این مورد روی Android 13 باعث کرش می‌شد).
- UI ساده است، تمرکز فقط روی اجرا و ثبات است.
