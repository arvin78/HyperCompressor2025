package com.hypercompressor2025

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hypercompressor2025.databinding.ItemVideoBinding
import java.text.DecimalFormat
import kotlin.math.log10
import kotlin.math.pow

class VideoAdapter : RecyclerView.Adapter<VideoAdapter.VH>() {

    private var items: List<VideoEntry> = emptyList()

    fun submit(newItems: List<VideoEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    class VH(private val binding: ItemVideoBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: VideoEntry) {
            binding.txtName.text = item.name
            val sizeStr = if (item.sizeBytes > 0) humanBytes(item.sizeBytes) else "?"
            binding.txtInfo.text = "$sizeStr • ${item.uri}"
        }

        private fun humanBytes(bytes: Long): String {
            val unit = 1024.0
            if (bytes < unit) return "$bytes B"
            val exp = (log10(bytes.toDouble()) / log10(unit)).toInt()
            val pre = "KMGTPE"[exp - 1]
            val df = DecimalFormat("#.##")
            return df.format(bytes / unit.pow(exp.toDouble())) + " " + pre + "B"
        }
    }
}
