\
package com.hypercompressor2025.worker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.ServiceInfo
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.lang.reflect.Proxy
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

class CompressWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val uriStr = inputData.getString(KEY_URI) ?: return Result.failure()
        val displayName = inputData.getString(KEY_NAME) ?: "video"
        val preset = inputData.getInt(KEY_PRESET, 1)

        setForeground(createForegroundInfo("درحال فشرده‌سازی: $displayName"))

        val tempOutFile = makeTempOutputFile(displayName)
        val tempOutPath = tempOutFile.absolutePath

        return try {
            runTransformer(uriStr, tempOutPath, preset)

            // Save into Gallery (Movies/HyperCompressor)
            val publishedUri = publishToGallery(tempOutFile, displayName)
            // Delete temp to save space
            try { tempOutFile.delete() } catch (_: Throwable) {}

            Result.success(
                workDataOf(
                    KEY_OUTPUT_URI to (publishedUri?.toString() ?: ""),
                    KEY_OUTPUT_PATH to tempOutPath
                )
            )
        } catch (t: Throwable) {
            writeLastError(t)
            Result.failure(workDataOf(KEY_ERROR to (t.message ?: "unknown")))
        }
    }

    private suspend fun runTransformer(inputUri: String, outputPath: String, preset: Int) {
        val handlerThread = HandlerThread("HC-Transformer").apply { start() }
        val handler = Handler(handlerThread.looper)

        suspendCancellableCoroutine<Unit> { cont ->
            val finished = AtomicBoolean(false)
            var transformerRef: Any? = null

            val listener = Proxy.newProxyInstance(
                Transformer.Listener::class.java.classLoader,
                arrayOf(Transformer.Listener::class.java)
            ) { _, method, args ->
                if (finished.get()) return@newProxyInstance null

                val name = method.name
                when {
                    name.equals("onCompleted", ignoreCase = true)
                            || name.equals("onTransformationCompleted", ignoreCase = true)
                            || name.contains("Completed", ignoreCase = true) -> {
                        if (finished.compareAndSet(false, true)) {
                            cont.resume(Unit)
                            handlerThread.quitSafely()
                        }
                    }

                    name.equals("onError", ignoreCase = true)
                            || name.equals("onTransformationError", ignoreCase = true)
                            || name.contains("Error", ignoreCase = true) -> {
                        val throwable = args?.firstOrNull { it is Throwable } as? Throwable
                        if (finished.compareAndSet(false, true)) {
                            cont.resumeWithException(throwable ?: RuntimeException("Transformer error"))
                            handlerThread.quitSafely()
                        }
                    }
                }
                null
            } as Transformer.Listener

            handler.post {
                try {
                    val mediaItem = MediaItem.fromUri(inputUri)
                    val edited = EditedMediaItem.Builder(mediaItem).build()

                    val builder = Transformer.Builder(applicationContext)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .addListener(listener)

                    val targetBitrate = when (preset) {
                        0 -> 4_000_000
                        1 -> 2_500_000
                        else -> 1_500_000
                    }
                    trySetBitrate(builder, targetBitrate)

                    val transformer = builder.build()
                    transformerRef = transformer
                    transformer.start(edited, outputPath)
                } catch (t: Throwable) {
                    if (finished.compareAndSet(false, true)) {
                        cont.resumeWithException(t)
                        handlerThread.quitSafely()
                    }
                }
            }

            cont.invokeOnCancellation {
                handler.post {
                    try {
                        val tr = transformerRef
                        tr?.javaClass?.getMethod("cancel")?.invoke(tr)
                    } catch (_: Throwable) {
                    } finally {
                        handlerThread.quitSafely()
                    }
                }
            }
        }
    }

    private fun trySetBitrate(builder: Transformer.Builder, bitrate: Int) {
        try {
            val ctx = applicationContext

            val videoEncoderSettingsCls = Class.forName("androidx.media3.transformer.VideoEncoderSettings")
            val videoEncoderSettingsBuilderCls = Class.forName("androidx.media3.transformer.VideoEncoderSettings\$Builder")
            val settingsBuilder = videoEncoderSettingsBuilderCls.getConstructor().newInstance()
            videoEncoderSettingsBuilderCls.getMethod("setBitrate", Int::class.javaPrimitiveType)
                .invoke(settingsBuilder, bitrate)
            val settings = videoEncoderSettingsBuilderCls.getMethod("build").invoke(settingsBuilder)

            val encoderFactoryInterface = Class.forName("androidx.media3.transformer.EncoderFactory")
            val defEncBuilderCls = Class.forName("androidx.media3.transformer.DefaultEncoderFactory\$Builder")
            val defEncBuilder = defEncBuilderCls.getConstructor(Context::class.java).newInstance(ctx)
            defEncBuilderCls.getMethod("setRequestedVideoEncoderSettings", videoEncoderSettingsCls)
                .invoke(defEncBuilder, settings)
            val encoderFactory = defEncBuilderCls.getMethod("build").invoke(defEncBuilder)

            builder.javaClass.getMethod("setEncoderFactory", encoderFactoryInterface)
                .invoke(builder, encoderFactory)
        } catch (_: Throwable) {
        }
    }

    private fun makeTempOutputFile(originalName: String): File {
        val safe = originalName.replace(Regex("[^a-zA-Z0-9._-]+"), "_")
        val dir = File(applicationContext.cacheDir, "hc_out")
        if (!dir.exists()) dir.mkdirs()
        val base = safe.substringBeforeLast('.', safe)
        val outName = "${base}_HC_${System.currentTimeMillis()}.mp4"
        return File(dir, outName)
    }

    private fun publishToGallery(tempFile: File, originalName: String): Uri? {
        val resolver = applicationContext.contentResolver
        val safe = originalName.replace(Regex("[^a-zA-Z0-9._-]+"), "_")
        val base = safe.substringBeforeLast('.', safe)
        val outName = "${base}_HC_${System.currentTimeMillis()}.mp4"

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, outName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/HyperCompressor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val itemUri = resolver.insert(collection, values) ?: return null

        try {
            resolver.openOutputStream(itemUri)?.use { out ->
                FileInputStream(tempFile).use { inp ->
                    inp.copyTo(out, 1024 * 1024)
                }
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                resolver.update(itemUri, done, null, null)
            }
            return itemUri
        } catch (t: Throwable) {
            try { resolver.delete(itemUri, null, null) } catch (_: Throwable) {}
            throw t
        }
    }

    private fun createForegroundInfo(text: String): ForegroundInfo {
        val channelId = "hc_progress"
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId,
                "HyperCompressor",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("HyperCompressor 2025")
            .setContentText(text)
            .setOngoing(true)
            .build()

        val id = 1001

        return if (Build.VERSION.SDK_INT >= 29) {
            ForegroundInfo(id, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(id, notification)
        }
    }


    private fun publishErrorToDownloads(text: String) {
        try {
            if (Build.VERSION.SDK_INT < 29) return
            val resolver = applicationContext.contentResolver
            val name = "hc_last_error_${System.currentTimeMillis()}.txt"

            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HyperCompressor")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
            }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (_: Throwable) {
        }
    }

    private fun writeLastError(t: Throwable) {
        try {
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            val text = sw.toString()
            // Save in internal (dev) + also export to Downloads so you can find it easily
            val f = File(applicationContext.filesDir, "hc_last_error.txt")
            f.writeText(text)
            publishErrorToDownloads(text)
        } catch (_: Throwable) {
        }
    }

    companion object {
        const val UNIQUE_WORK_NAME = "hc_compress_chain"
        const val TAG_WORK = "hc_compress"

        const val KEY_URI = "uri"
        const val KEY_NAME = "name"
        const val KEY_PRESET = "preset"

        const val KEY_OUTPUT_PATH = "outputPath"
        const val KEY_OUTPUT_URI = "outputUri"
        const val KEY_ERROR = "error"
    }
}
