package com.hypercompressor2025

data class VideoEntry(
    val uri: String,
    val name: String,
    val sizeBytes: Long
)
