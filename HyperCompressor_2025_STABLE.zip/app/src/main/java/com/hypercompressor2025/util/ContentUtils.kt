package com.hypercompressor2025.util

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns

object ContentUtils {

    fun displayName(resolver: ContentResolver, uri: Uri): String? {
        return try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
        } catch (_: Throwable) {
            null
        }
    }

    fun sizeBytes(resolver: ContentResolver, uri: Uri): Long? {
        return try {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) c.getLong(0) else null
                }
        } catch (_: Throwable) {
            null
        }
    }
}
