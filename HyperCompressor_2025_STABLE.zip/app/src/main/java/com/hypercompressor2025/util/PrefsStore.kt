package com.hypercompressor2025.util

import android.content.Context
import com.hypercompressor2025.VideoEntry
import org.json.JSONArray
import org.json.JSONObject

class PrefsStore(context: Context) {

    private val prefs = context.getSharedPreferences("hc_prefs", Context.MODE_PRIVATE)

    fun saveVideos(list: List<VideoEntry>) {
        val arr = JSONArray()
        for (v in list) {
            val o = JSONObject()
            o.put("uri", v.uri)
            o.put("name", v.name)
            o.put("sizeBytes", v.sizeBytes)
            arr.put(o)
        }
        prefs.edit().putString("videos", arr.toString()).apply()
    }

    fun loadVideos(): List<VideoEntry> {
        val raw = prefs.getString("videos", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<VideoEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    VideoEntry(
                        uri = o.optString("uri", ""),
                        name = o.optString("name", "video"),
                        sizeBytes = o.optLong("sizeBytes", -1L)
                    )
                )
            }
            out.filter { it.uri.isNotBlank() }
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
