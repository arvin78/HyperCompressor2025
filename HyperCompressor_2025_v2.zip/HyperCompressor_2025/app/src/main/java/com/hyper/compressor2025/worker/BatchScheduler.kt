package com.hyper.compressor2025.worker

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.hyper.compressor2025.data.QueueItem

object BatchScheduler {
  const val UNIQUE_WORK = "hypercompress_batch"

  fun enqueue(context: Context, items: List<QueueItem>) {
    if (items.isEmpty()) return
    val wm = WorkManager.getInstance(context)

    val requests = items.map {
      OneTimeWorkRequestBuilder<CompressWorker>()
        .setInputData(
          workDataOf(
            CompressWorker.KEY_ITEM_ID to it.id,
            CompressWorker.KEY_URI to it.uri,
            CompressWorker.KEY_NAME to it.name
          )
        )
        .addTag(UNIQUE_WORK)
        .build()
    }

    // صف پشت هم (sequential)
    var cont = wm.beginUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.APPEND_OR_REPLACE, requests.first())
    for (r in requests.drop(1)) cont = cont.then(r)
    cont.enqueue()
  }
}
