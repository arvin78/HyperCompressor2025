package com.hyper.compressor2025.ui

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.snackbar.Snackbar
import com.hyper.compressor2025.BuildConfig
import com.hyper.compressor2025.data.ItemState
import com.hyper.compressor2025.data.QueueItem
import com.hyper.compressor2025.data.QueueStore
import com.hyper.compressor2025.databinding.ActivityMainBinding
import com.hyper.compressor2025.util.Formatters
import com.hyper.compressor2025.util.SafUtils
import com.hyper.compressor2025.worker.BatchScheduler
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {

  private lateinit var b: ActivityMainBinding
  private lateinit var store: QueueStore
  private lateinit var adapter: QueueAdapter

  private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
    refresh()
  }

  private val pickVideos = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
    if (uris.isNullOrEmpty()) return@registerForActivityResult
    val items = uris.map { uri ->
      SafUtils.persistRead(this, uri)
      QueueItem(
        id = UUID.randomUUID().toString(),
        uri = uri.toString(),
        name = SafUtils.displayName(this, uri),
        state = ItemState.QUEUED,
        progress = 0,
        outputPath = null,
        error = null
      )
    }
    store.add(items)
    BatchScheduler.enqueue(this, items)
  }

  private val requestNotifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    b = ActivityMainBinding.inflate(layoutInflater)
    setContentView(b.root)

    setSupportActionBar(b.toolbar)

    store = QueueStore(this)
    adapter = QueueAdapter { openOutput(it) }
    b.recycler.adapter = adapter

    b.fab.setOnClickListener {
      maybeRequestNotifications()
      pickVideos.launch(arrayOf("video/*"))
    }

    store.registerListener(prefListener)
    refresh()
  }

  override fun onDestroy() {
    super.onDestroy()
    store.unregisterListener(prefListener)
  }

  private fun refresh() {
    val items = store.load()
    b.emptyState.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    adapter.submitList(items)

    if (items.isEmpty()) {
      b.batchSubtitle.text = "—"
      b.batchProgress.setProgressCompat(0, true)
      return
    }

    val avg = (items.sumOf { it.progress.coerceIn(0,100) }.toDouble() / items.size).toInt().coerceIn(0,100)
    val done = items.count { it.state == ItemState.DONE || it.state == ItemState.FAILED }
    val running = items.count { it.state == ItemState.RUNNING }
    val queued = items.count { it.state == ItemState.QUEUED }

    b.batchProgress.setProgressCompat(avg, true)
    b.batchSubtitle.text = "Total " + Formatters.pct(avg) + " • " + done + "/" + items.size + " done • " + running + " running • " + queued + " queued"
  }

  private fun openOutput(item: QueueItem) {
    val path = item.outputPath ?: return
    val file = File(path)
    if (!file.exists()) {
      Snackbar.make(b.root, "فایل خروجی پیدا نشد", Snackbar.LENGTH_LONG).show()
      return
    }
    val uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
      setDataAndType(uri, "video/*")
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { startActivity(intent) }
      .onFailure { Snackbar.make(b.root, "برنامه‌ای برای باز کردن ویدیو پیدا نشد", Snackbar.LENGTH_LONG).show() }
  }

  private fun maybeRequestNotifications() {
    if (Build.VERSION.SDK_INT < 33) return
    val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    if (!granted) requestNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
  }
}
