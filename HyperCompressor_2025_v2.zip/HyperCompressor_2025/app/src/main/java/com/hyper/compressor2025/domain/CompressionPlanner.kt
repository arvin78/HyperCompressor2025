package com.hyper.compressor2025.domain

import com.hyper.compressor2025.util.VideoMeta
import kotlin.math.max
import kotlin.math.roundToInt

object CompressionPlanner {

  // هدف: حدود 95% کاهش (یعنی 5% حجم ورودی)
  fun targetBytes95(inputBytes: Long): Long {
    if (inputBytes <= 0) return 100L * 1024L * 1024L
    val raw = (inputBytes * 0.05).toLong()
    val min = 30L * 1024L * 1024L
    val max = 500L * 1024L * 1024L
    return raw.coerceIn(min, max)
  }

  // بیت‌ریت تقریبی برای رسیدن به اندازه هدف (با کمی حاشیه)
  fun videoBitrateBps(targetBytes: Long, meta: VideoMeta): Int {
    val durSec = max(1.0, meta.durationMs / 1000.0)
    val totalBps = ((targetBytes * 8.0) / durSec).roundToInt()
    val audio = 96_000
    val video = (totalBps - audio).coerceIn(800_000, 6_000_000)
    return video
  }

  fun maxHeight(meta: VideoMeta, targetBytes: Long): Int {
    // قانون: تا وقتی ممکنه 1080 نگه دار، فقط اگر خیلی کم بود برو پایین
    val h = if (meta.height <= 0) 1080 else meta.height
    val durSec = max(1.0, meta.durationMs / 1000.0)
    val totalBps = ((targetBytes * 8.0) / durSec)
    // اگر زیر ~1.2Mbps بود احتمالاً 1080 کیفیت افت می‌کنه => 720
    return when {
      h > 1080 -> 1080
      h >= 1080 && totalBps < 1_200_000 -> 720
      else -> h
    }
  }
}
