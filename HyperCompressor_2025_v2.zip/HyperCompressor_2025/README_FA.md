# ساخت APK فقط با گوشی (ZIP + Actions)

1) فقط یک فایل ZIP از پروژه را در ریشه ریپو آپلود کن.
2) فایل `.github/workflows/build.yml` را بساز (من کدش را می‌دهم).
3) تب Actions → دانلود Artifact.

اگر Build Fail شد، Logs را همینجا بفرست.
