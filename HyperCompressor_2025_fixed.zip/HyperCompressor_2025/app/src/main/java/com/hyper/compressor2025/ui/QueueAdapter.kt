package com.hyper.compressor2025.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.hyper.compressor2025.data.ItemState
import com.hyper.compressor2025.data.QueueItem
import com.hyper.compressor2025.databinding.ItemQueueBinding
import com.hyper.compressor2025.util.Formatters

class QueueAdapter(
    private val onOpen: (QueueItem) -> Unit
) : ListAdapter<QueueItem, QueueAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemQueueBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position), onOpen)
    }

    class VH(private val b: ItemQueueBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: QueueItem, onOpen: (QueueItem) -> Unit) {
            b.title.text = item.name

            val stateLabel = when (item.state) {
                ItemState.QUEUED -> "Queued"
                ItemState.RUNNING -> "Compressing…"
                ItemState.DONE -> "Done"
                ItemState.FAILED -> "Failed"
                ItemState.SKIPPED -> "Skipped"
            }

            val inB = Formatters.bytes(item.inputBytes)
            val tgtB = Formatters.bytes(item.targetBytes)
            val outB = Formatters.bytes(item.outputBytes)
            val extra = buildString {
                append("In "); append(inB)
                append(" → Target "); append(tgtB)
                if (item.state == ItemState.DONE) {
                    append(" → Out "); append(outB)
                }
                item.error?.takeIf { it.isNotBlank() }?.let {
                    append(" • "); append(it)
                }
            }

            b.subtitle.text = stateLabel + " • " + extra

            val p = item.progress.coerceIn(0, 100)
            b.progress.setProgressCompat(p, true)
            b.progressText.text = Formatters.pct(p)

            val canOpen = item.state == ItemState.DONE && !item.outputPath.isNullOrBlank()
            b.openButton.isEnabled = canOpen
            b.openButton.alpha = if (canOpen) 1f else 0.4f
            b.openButton.setOnClickListener {
                if (canOpen) onOpen(item)
            }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<QueueItem>() {
            override fun areItemsTheSame(oldItem: QueueItem, newItem: QueueItem): Boolean = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: QueueItem, newItem: QueueItem): Boolean = oldItem == newItem
        }
    }
}
