package com.hyper.compressor2025.domain

import com.hyper.compressor2025.util.VideoMeta
import kotlin.math.max
import kotlin.math.roundToInt

data class Plan(
    val targetBytes: Long,
    val videoBitrateBps: Int,
    val audioBitrateBps: Int,
    val maxHeight: Int
)

object CompressionPlanner {

    private const val AUDIO_BITRATE_BPS = 96_000

    private const val MIN_TARGET_BYTES = 30L * 1024L * 1024L
    private const val MAX_TARGET_BYTES = 500L * 1024L * 1024L

    private const val MIN_TOTAL_BITRATE_BPS = 800_000
    private const val MAX_TOTAL_BITRATE_BPS = 8_000_000
    private const val MIN_VIDEO_BITRATE_BPS = 600_000
    private const val MAX_VIDEO_BITRATE_BPS = 7_500_000

    private const val BPPF_DOWNGRADE_TO_720 = 0.040
    private const val BPPF_DOWNGRADE_TO_540 = 0.032

    fun planFor95PercentReduction(inputBytes: Long, meta: VideoMeta): Plan {
        val durationSec = max(1.0, meta.durationMs / 1000.0)

        val rawTarget = if (inputBytes > 0) (inputBytes * 0.05).roundToInt().toLong() else (100L * 1024L * 1024L)
        val targetBytes = rawTarget.coerceIn(MIN_TARGET_BYTES, MAX_TARGET_BYTES)

        val totalBitrate = ((targetBytes * 8.0) / durationSec)
            .roundToInt()
            .coerceIn(MIN_TOTAL_BITRATE_BPS, MAX_TOTAL_BITRATE_BPS)

        var videoBitrate = (totalBitrate - AUDIO_BITRATE_BPS)
            .coerceIn(MIN_VIDEO_BITRATE_BPS, MAX_VIDEO_BITRATE_BPS)

        val fps = max(1f, meta.fps)
        fun bppf(bps: Int, w: Int, h: Int): Double {
            val ww = max(1, w)
            val hh = max(1, h)
            return bps.toDouble() / (ww.toDouble() * hh.toDouble() * fps.toDouble())
        }

        val cap1080 = if (meta.height > 1080) 1080 else max(1, meta.height)
        var maxHeight = cap1080

        if (maxHeight >= 1080 && bppf(videoBitrate, meta.width, maxHeight) < BPPF_DOWNGRADE_TO_720) {
            maxHeight = 720
        }
        if (maxHeight >= 720 && bppf(videoBitrate, meta.width, maxHeight) < BPPF_DOWNGRADE_TO_540) {
            maxHeight = 540
        }

        val minForRes = when {
            maxHeight >= 1080 -> 1_600_000
            maxHeight >= 720 -> 1_000_000
            else -> 700_000
        }
        videoBitrate = maxOf(videoBitrate, minForRes)

        return Plan(
            targetBytes = targetBytes,
            videoBitrateBps = videoBitrate,
            audioBitrateBps = AUDIO_BITRATE_BPS,
            maxHeight = maxHeight
        )
    }
}
