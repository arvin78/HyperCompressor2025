package com.hyper.compressor2025.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

enum class ItemState {
    QUEUED, RUNNING, DONE, FAILED, SKIPPED
}

data class QueueItem(
    val id: String,
    val uri: String,
    val name: String,
    val inputBytes: Long,
    val targetBytes: Long,
    val state: ItemState,
    val progress: Int,
    val outputPath: String?,
    val outputBytes: Long?,
    val error: String?
)

data class QueueSnapshot(
    val items: List<QueueItem>,
    val activeId: String?
)

class QueueStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun addItems(items: List<QueueItem>) {
        val snap = load()
        val merged = ArrayList<QueueItem>(snap.items.size + items.size)
        merged.addAll(snap.items)
        merged.addAll(items)
        save(QueueSnapshot(merged, snap.activeId))
    }

    fun setActive(activeId: String?) {
        val snap = load()
        save(QueueSnapshot(snap.items, activeId))
    }

    fun updateItem(
        id: String,
        state: ItemState? = null,
        progress: Int? = null,
        outputPath: String? = null,
        outputBytes: Long? = null,
        error: String? = null
    ) {
        val snap = load()
        val updated = snap.items.map {
            if (it.id != id) it else it.copy(
                state = state ?: it.state,
                progress = progress ?: it.progress,
                outputPath = outputPath ?: it.outputPath,
                outputBytes = outputBytes ?: it.outputBytes,
                error = error ?: it.error
            )
        }
        save(QueueSnapshot(updated, snap.activeId))
    }

    fun nextQueued(): QueueItem? {
        val snap = load()
        return snap.items.firstOrNull { it.state == ItemState.QUEUED }
    }

    fun load(): QueueSnapshot {
        val raw = prefs.getString(KEY_JSON, null) ?: return QueueSnapshot(emptyList(), null)
        return runCatching {
            val obj = JSONObject(raw)
            val active = obj.optString("activeId", null)
            val arr = obj.optJSONArray("items") ?: JSONArray()
            val items = buildList {
                for (i in 0 until arr.length()) {
                    val it = arr.getJSONObject(i)
                    add(
                        QueueItem(
                            id = it.getString("id"),
                            uri = it.getString("uri"),
                            name = it.getString("name"),
                            inputBytes = it.optLong("inputBytes", -1L),
                            targetBytes = it.optLong("targetBytes", -1L),
                            state = ItemState.valueOf(it.optString("state", ItemState.QUEUED.name)),
                            progress = it.optInt("progress", 0),
                            outputPath = it.optString("outputPath", null),
                            outputBytes = it.optLong("outputBytes", -1L).takeIf { v -> v > 0 },
                            error = it.optString("error", null)
                        )
                    )
                }
            }
            QueueSnapshot(items, active)
        }.getOrElse {
            QueueSnapshot(emptyList(), null)
        }
    }

    fun clearAll() {
        prefs.edit().remove(KEY_JSON).apply()
    }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    private fun save(snapshot: QueueSnapshot) {
        val obj = JSONObject()
        snapshot.activeId?.let { obj.put("activeId", it) }
        val arr = JSONArray()
        for (it in snapshot.items) {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("uri", it.uri)
            o.put("name", it.name)
            o.put("inputBytes", it.inputBytes)
            o.put("targetBytes", it.targetBytes)
            o.put("state", it.state.name)
            o.put("progress", it.progress)
            it.outputPath?.let { p -> o.put("outputPath", p) }
            it.outputBytes?.let { b -> o.put("outputBytes", b) }
            it.error?.let { e -> o.put("error", e) }
            arr.put(o)
        }
        obj.put("items", arr)
        prefs.edit().putString(KEY_JSON, obj.toString()).apply()
    }

    companion object {
        private const val PREFS = "queue_store"
        private const val KEY_JSON = "queue_json"
    }
}
