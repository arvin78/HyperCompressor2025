package com.hyper.compressor2025.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.MediaCodecInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.HandlerThread
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.TransformationRequest
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.hyper.compressor2025.data.ItemState
import com.hyper.compressor2025.data.QueueStore
import com.hyper.compressor2025.domain.CompressionPlanner
import com.hyper.compressor2025.util.CodecSupport
import com.hyper.compressor2025.util.SafUtils
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.io.File
import kotlin.coroutines.coroutineContext

class BatchCompressionWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    private var transformer: Transformer? = null

    override suspend fun doWork(): Result {
        val store = QueueStore(applicationContext)
        ensureChannel(applicationContext)

        val notifId = 1001
        setForegroundAsync(makeFg(notifId, "صف آماده است", 0, "Queued"))

        while (coroutineContext.isActive) {
            val next = store.nextQueued() ?: break

            store.setActive(next.id)
            store.updateItem(next.id, state = ItemState.RUNNING, progress = 0, error = null)

            val uri = Uri.parse(next.uri)

            val meta = SafUtils.readVideoMeta(applicationContext, uri)
            if (meta.durationMs <= 0) {
                store.updateItem(next.id, state = ItemState.FAILED, progress = 100, error = "فایل خراب یا غیرقابل خواندن")
                store.setActive(null)
                continue
            }

            val plan = CompressionPlanner.planFor95PercentReduction(next.inputBytes, meta)
            val outFile = createOutputFile(next.name)

            val preferredMime = CodecSupport.preferredVideoMime()

            val result = transcodeOne(
                uri = uri,
                outputPath = outFile.absolutePath,
                maxHeight = plan.maxHeight,
                videoMime = preferredMime,
                videoBitrate = plan.videoBitrateBps,
                audioBitrate = plan.audioBitrateBps,
                notifId = notifId,
                title = next.name,
                onProgress = { p -> store.updateItem(next.id, progress = p) }
            )

            if (result.success) {
                val outBytes = runCatching { outFile.length() }.getOrDefault(-1L)
                store.updateItem(
                    next.id,
                    state = ItemState.DONE,
                    progress = 100,
                    outputPath = outFile.absolutePath,
                    outputBytes = outBytes,
                    error = null
                )
            } else {
                // Retry once with H.264 if HEVC/AV1 failed (device limitation).
                val retry = transcodeOne(
                    uri = uri,
                    outputPath = outFile.absolutePath,
                    maxHeight = plan.maxHeight,
                    videoMime = MimeTypes.VIDEO_H264,
                    videoBitrate = plan.videoBitrateBps,
                    audioBitrate = plan.audioBitrateBps,
                    notifId = notifId,
                    title = next.name,
                    isRetry = true,
                    onProgress = { p -> store.updateItem(next.id, progress = p) }
                )

                if (retry.success) {
                    val outBytes = runCatching { outFile.length() }.getOrDefault(-1L)
                    store.updateItem(
                        next.id,
                        state = ItemState.DONE,
                        progress = 100,
                        outputPath = outFile.absolutePath,
                        outputBytes = outBytes,
                        error = "Fallback: H.264"
                    )
                } else {
                    store.updateItem(
                        next.id,
                        state = ItemState.FAILED,
                        progress = 100,
                        error = (retry.error ?: result.error ?: "Unknown error").take(180)
                    )
                }
            }

            store.setActive(null)
            delay(150)
        }

        NotificationManagerCompat.from(applicationContext).notify(
            1001,
            buildNotif("پایان", "صف تمام شد", 100)
        )
        return Result.success()
    }
    private data class OneResult(val success: Boolean, val error: String? = null)

    private suspend fun transcodeOne(
        uri: Uri,
        outputPath: String,
        maxHeight: Int,
        videoMime: String,
        videoBitrate: Int,
        audioBitrate: Int,
        notifId: Int,
        title: String,
        isRetry: Boolean = false,
        onProgress: (Int) -> Unit
    ): OneResult {
        val handlerThread = HandlerThread("Transformer").apply { start() }
        val completion = CompletableDeferred<OneResult>()

        val request = TransformationRequest.Builder()
            .setVideoMimeType(videoMime)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .build()

        val vSettings = VideoEncoderSettings.Builder()
            .setBitrate(videoBitrate)
            .setBitrateMode(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            .setiFrameIntervalSeconds(2.0f)
            .build()
        val encoderFactory = DefaultEncoderFactory.Builder(applicationContext)
            .setRequestedVideoEncoderSettings(vSettings)
                        .build()

        val effects = if (maxHeight > 0) {
            Effects(emptyList(), listOf(Presentation.createForHeight(maxHeight)))
        } else {
            Effects(emptyList(), emptyList())
        }

        val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
            .setEffects(effects)
            .build()

        val t = Transformer.Builder(applicationContext)
            .setTransformationRequest(request)
            .setEncoderFactory(encoderFactory)
            .setLooper(handlerThread.looper)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult
                ) {
                    completion.complete(OneResult(true))
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    val msg = buildString {
                        append("E"); append(exportException.errorCode)
                        exportException.message?.let {
                            append(": "); append(it)
                        }
                    }
                    completion.complete(OneResult(false, msg))
                }
            })
            .build()

        transformer = t

        try {
            t.start(edited, outputPath)

            val ph = ProgressHolder()
            var last = -1
            while (!completion.isCompleted && coroutineContext.isActive) {
                val state = t.getProgress(ph)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val p = ph.progress.coerceIn(0, 100)
                    if (p != last) {
                        last = p
                        onProgress(p)
                        setForegroundAsync(makeFg(notifId, title, p, if (isRetry) "Retry" else "Compressing"))
                        NotificationManagerCompat.from(applicationContext).notify(
                            notifId,
                            buildNotif(if (isRetry) "Retry" else "Compressing", title, p)
                        )
                    }
                }
                delay(250)
            }
            return completion.await()
        } catch (e: Throwable) {
            return OneResult(false, "Crash: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            runCatching { t.cancel() }
            runCatching { handlerThread.quitSafely() }
            transformer = null
        }
    }

    private fun createOutputFile(displayName: String): File {
        val safe = displayName.replace(Regex("[^a-zA-Z0-9._-]+"), "_").take(48).ifBlank { "video" }
        val dir = applicationContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: applicationContext.filesDir
        if (!dir.exists()) dir.mkdirs()
        val fileName = "hyper_" + System.currentTimeMillis() + "_" + safe + ".mp4"
        return File(dir, fileName)
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val mgr = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (mgr.getNotificationChannel(CHANNEL_ID) != null) return
        mgr.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Compression", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotif(status: String, name: String, progress: Int) =
        NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("HyperCompressor")
            .setContentText(status + " • " + name)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .build()

    private fun makeFg(id: Int, name: String, progress: Int, status: String): ForegroundInfo {
        val notif = buildNotif(status, name, progress)
        // targetSdk is 33 in this project so we can use the 2-arg ForegroundInfo constructor safely.
        return ForegroundInfo(id, notif)
    }
    }

    companion object {
        const val UNIQUE_NAME = "hypercompress_batch"
        private const val CHANNEL_ID = "hypercompress_channel"

        fun ensureRunning(context: Context) {
            val req = OneTimeWorkRequestBuilder<BatchCompressionWorker>()
                .addTag(UNIQUE_NAME)
                .build()

            WorkManager.getInstance(context)
                .enqueueUniqueWork(UNIQUE_NAME, ExistingWorkPolicy.KEEP, req)
        }
    }
}
