package com.hyper.compressor2025.util

import android.media.MediaCodecList
import androidx.media3.common.MimeTypes

object CodecSupport {

    private fun supportsHardwareEncoder(mime: String): Boolean {
        val list = MediaCodecList(MediaCodecList.ALL_CODECS)
        for (info in list.codecInfos) {
            if (!info.isEncoder) continue
            val types = runCatching { info.supportedTypes }.getOrNull() ?: continue
            if (!types.any { it.equals(mime, ignoreCase = true) }) continue

            val name = info.name.lowercase()
            val looksSoftware =
                name.contains("google") ||
                name.contains("sw") ||
                name.contains("software") ||
                name.contains("c2.android") ||
                name.contains("omx.google")
            if (!looksSoftware) return true
        }
        return false
    }

    fun preferredVideoMime(): String {
        return when {
            supportsHardwareEncoder(MimeTypes.VIDEO_H265) -> MimeTypes.VIDEO_H265
            supportsHardwareEncoder(MimeTypes.VIDEO_AV1) -> MimeTypes.VIDEO_AV1
            else -> MimeTypes.VIDEO_H265
        }
    }
}
