package com.hyper.compressor2025.util

import kotlin.math.ln
import kotlin.math.pow

object Formatters {
    fun bytes(bytes: Long?): String {
        if (bytes == null || bytes < 0) return "—"
        if (bytes == 0L) return "0 B"
        val k = 1024.0
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val i = (ln(bytes.toDouble()) / ln(k)).toInt().coerceIn(0, units.size - 1)
        val v = bytes / k.pow(i.toDouble())
        return if (i == 0) "${bytes} B" else String.format("%.1f %s", v, units[i])
    }

    fun pct(p: Int): String = "${p.coerceIn(0, 100)}%"
}
