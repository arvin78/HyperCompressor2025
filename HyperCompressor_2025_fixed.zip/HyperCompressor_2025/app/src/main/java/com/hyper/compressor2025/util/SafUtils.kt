package com.hyper.compressor2025.util

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

data class VideoMeta(
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Float
)

object SafUtils {

    fun persistRead(context: Context, uri: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun displayName(context: Context, uri: Uri): String {
        val cr = context.contentResolver
        val name = runCatching {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
        return name ?: "Video"
    }

    fun sizeBytes(context: Context, uri: Uri): Long {
        val cr = context.contentResolver
        val viaQuery = runCatching {
            cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            }
        }.getOrNull() ?: -1L
        if (viaQuery > 0) return viaQuery

        return runCatching {
            cr.openAssetFileDescriptor(uri, "r")?.use { afd ->
                val s = afd.length
                if (s > 0) s else -1L
            } ?: -1L
        }.getOrNull() ?: -1L
    }

    fun readVideoMeta(context: Context, uri: Uri): VideoMeta {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val fpsStr =
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
            val fps = fpsStr?.toFloatOrNull()?.takeIf { it > 0f } ?: 30f
            VideoMeta(dur, w, h, fps)
        } catch (_: Throwable) {
            VideoMeta(0L, 0, 0, 30f)
        } finally {
            runCatching { r.release() }
        }
    }
}
