package com.hyper.compressor2025.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

enum class ItemState { QUEUED, RUNNING, DONE, FAILED }

data class QueueItem(
  val id: String,
  val uri: String,
  val name: String,
  val inputBytes: Long,
  val targetBytes: Long,
  val state: ItemState,
  val progress: Int,
  val outputPath: String?,
  val outputBytes: Long,
  val error: String?
)

class QueueStore(context: Context) {
  private val prefs: SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  fun add(items: List<QueueItem>) {
    val cur = load().toMutableList()
    cur.addAll(items)
    save(cur)
  }

  fun replaceAll(items: List<QueueItem>) {
    save(items)
  }

  fun update(
    id: String,
    state: ItemState? = null,
    progress: Int? = null,
    outputPath: String? = null,
    outputBytes: Long? = null,
    error: String? = null
  ) {
    val cur = load().map {
      if (it.id != id) it else it.copy(
        state = state ?: it.state,
        progress = progress ?: it.progress,
        outputPath = outputPath ?: it.outputPath,
        outputBytes = outputBytes ?: it.outputBytes,
        error = error ?: it.error
      )
    }
    save(cur)
  }

  fun resetToQueued(id: String) {
    val cur = load().map {
      if (it.id != id) it else it.copy(state = ItemState.QUEUED, progress = 0, outputPath = null, outputBytes = 0, error = null)
    }
    save(cur)
  }

  fun clearFinished() {
    val cur = load().filter { it.state == ItemState.QUEUED || it.state == ItemState.RUNNING }
    save(cur)
  }

  fun clearAll() {
    prefs.edit().remove(KEY_JSON).apply()
  }

  fun load(): List<QueueItem> {
    val raw = prefs.getString(KEY_JSON, null) ?: return emptyList()
    return runCatching {
      val arr = JSONArray(raw)
      buildList {
        for (i in 0 until arr.length()) {
          val o = arr.getJSONObject(i)
          add(
            QueueItem(
              id = o.getString("id"),
              uri = o.getString("uri"),
              name = o.getString("name"),
              inputBytes = o.optLong("inputBytes", -1L),
              targetBytes = o.optLong("targetBytes", -1L),
              state = ItemState.valueOf(o.getString("state")),
              progress = o.optInt("progress", 0),
              outputPath = o.optString("outputPath", null),
              outputBytes = o.optLong("outputBytes", 0L),
              error = o.optString("error", null)
            )
          )
        }
      }
    }.getOrElse { emptyList() }
  }

  fun registerListener(l: SharedPreferences.OnSharedPreferenceChangeListener) {
    prefs.registerOnSharedPreferenceChangeListener(l)
  }

  fun unregisterListener(l: SharedPreferences.OnSharedPreferenceChangeListener) {
    prefs.unregisterOnSharedPreferenceChangeListener(l)
  }

  private fun save(items: List<QueueItem>) {
    val arr = JSONArray()
    for (it in items) {
      val o = JSONObject()
      o.put("id", it.id)
      o.put("uri", it.uri)
      o.put("name", it.name)
      o.put("inputBytes", it.inputBytes)
      o.put("targetBytes", it.targetBytes)
      o.put("state", it.state.name)
      o.put("progress", it.progress)
      o.put("outputBytes", it.outputBytes)
      it.outputPath?.let { p -> o.put("outputPath", p) }
      it.error?.let { e -> o.put("error", e) }
      arr.put(o)
    }
    prefs.edit().putString(KEY_JSON, arr.toString()).apply()
  }

  companion object {
    private const val PREFS = "queue_store"
    private const val KEY_JSON = "queue_json"
  }
}
