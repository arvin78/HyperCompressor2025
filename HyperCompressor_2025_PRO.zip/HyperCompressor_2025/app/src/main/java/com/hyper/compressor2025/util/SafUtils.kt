package com.hyper.compressor2025.util

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

data class VideoMeta(val durationMs: Long, val width: Int, val height: Int)

object SafUtils {
  fun persistRead(context: Context, uri: Uri) {
    runCatching {
      context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
  }

  fun displayName(context: Context, uri: Uri): String {
    val cr = context.contentResolver
    val name = runCatching {
      cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
      }
    }.getOrNull()
    return name ?: "Video"
  }

  fun sizeBytes(context: Context, uri: Uri): Long {
    val cr = context.contentResolver
    return runCatching {
      cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getLong(0) else -1L
      } ?: -1L
    }.getOrDefault(-1L)
  }

  fun meta(context: Context, uri: Uri): VideoMeta {
    val r = MediaMetadataRetriever()
    return try {
      r.setDataSource(context, uri)
      val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
      val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
      val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
      VideoMeta(dur, w, h)
    } catch (_: Throwable) {
      VideoMeta(0L, 0, 0)
    } finally {
      runCatching { r.release() }
    }
  }
}
