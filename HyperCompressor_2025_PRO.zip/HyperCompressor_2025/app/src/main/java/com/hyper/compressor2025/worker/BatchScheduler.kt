package com.hyper.compressor2025.worker

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.hyper.compressor2025.data.QueueItem

object BatchScheduler {
  const val UNIQUE_WORK = "hypercompress_batch"

  fun enqueueSequential(context: Context, items: List<QueueItem>) {
    if (items.isEmpty()) return
    val wm = WorkManager.getInstance(context)

    val reqs = items.map {
      OneTimeWorkRequestBuilder<CompressWorker>()
        .setInputData(
          workDataOf(
            CompressWorker.KEY_ITEM_ID to it.id,
            CompressWorker.KEY_URI to it.uri,
            CompressWorker.KEY_NAME to it.name
          )
        )
        .addTag(UNIQUE_WORK)
        .build()
    }

    // APPEND so new items join the end of the existing chain
    var cont = wm.beginUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.APPEND, reqs.first())
    for (r in reqs.drop(1)) cont = cont.then(r)
    cont.enqueue()
  }

  fun cancelAll(context: Context) {
    WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK)
  }
}
