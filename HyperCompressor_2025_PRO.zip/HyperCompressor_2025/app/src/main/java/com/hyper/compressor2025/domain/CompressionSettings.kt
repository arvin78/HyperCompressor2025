package com.hyper.compressor2025.domain

import android.content.Context

data class CompressionSettings(
  val targetRatio: Double = 0.05, // 95% reduction
  val prefer1080p: Boolean = true,
  val maxFpsAssumed: Double = 30.0
)

object SettingsStore {
  private const val PREFS = "settings"
  private const val KEY_RATIO = "ratio"
  private const val KEY_1080 = "prefer1080"

  fun load(context: Context): CompressionSettings {
    val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val r = p.getFloat(KEY_RATIO, 0.05f).toDouble().coerceIn(0.02, 0.30)
    val prefer = p.getBoolean(KEY_1080, true)
    return CompressionSettings(targetRatio = r, prefer1080p = prefer)
  }

  fun save(context: Context, s: CompressionSettings) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
      .putFloat(KEY_RATIO, s.targetRatio.toFloat())
      .putBoolean(KEY_1080, s.prefer1080p)
      .apply()
  }
}
