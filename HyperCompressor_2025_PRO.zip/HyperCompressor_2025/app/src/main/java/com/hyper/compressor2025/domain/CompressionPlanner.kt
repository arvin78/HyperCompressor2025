package com.hyper.compressor2025.domain

import com.hyper.compressor2025.util.VideoMeta
import kotlin.math.max
import kotlin.math.roundToInt

object CompressionPlanner {

  fun targetBytes(inputBytes: Long, ratio: Double): Long {
    if (inputBytes <= 0) return 120L * 1024L * 1024L
    val raw = (inputBytes * ratio).toLong()
    val min = 35L * 1024L * 1024L
    val max = 700L * 1024L * 1024L
    return raw.coerceIn(min, max)
  }

  fun chooseHeight(meta: VideoMeta, targetBytes: Long, prefer1080p: Boolean, assumedFps: Double): Int {
    val w = meta.width.takeIf { it > 0 } ?: 1920
    val h = meta.height.takeIf { it > 0 } ?: 1080
    val durSec = max(1.0, meta.durationMs / 1000.0)
    val totalBps = (targetBytes * 8.0) / durSec
    val audioBps = 96_000.0
    val videoBps = max(300_000.0, totalBps - audioBps)

    // bits-per-pixel-per-frame heuristic for HEVC-ish "visually ok on phone"
    fun bpppf(width: Int, height: Int) = videoBps / (width.toDouble() * height.toDouble() * assumedFps)

    // always downscale >1080p for phones
    val clampedH = if (h > 1080) 1080 else h
    if (!prefer1080p) return clampedH

    val bpp = bpppf(w, clampedH)
    // If bitrate is too low for 1080p, step down gradually (avoid blind 480p)
    return when {
      clampedH >= 1080 && bpp < 0.045 -> 720
      clampedH >= 720 && bpp < 0.040 -> 540
      else -> clampedH
    }
  }

  fun videoBitrateBps(targetBytes: Long, meta: VideoMeta): Int {
    val durSec = max(1.0, meta.durationMs / 1000.0)
    val totalBps = ((targetBytes * 8.0) / durSec).roundToInt()
    val audio = 96_000
    // clamp: avoid ultra-low bitrates that look awful, and avoid wasting size
    return (totalBps - audio).coerceIn(900_000, 8_000_000)
  }
}
