package com.hyper.compressor2025.ui

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.snackbar.Snackbar
import com.hyper.compressor2025.BuildConfig
import com.hyper.compressor2025.R
import com.hyper.compressor2025.data.ItemState
import com.hyper.compressor2025.data.QueueItem
import com.hyper.compressor2025.data.QueueStore
import com.hyper.compressor2025.databinding.ActivityMainBinding
import com.hyper.compressor2025.domain.CompressionPlanner
import com.hyper.compressor2025.domain.SettingsStore
import com.hyper.compressor2025.util.Formatters
import com.hyper.compressor2025.util.SafUtils
import com.hyper.compressor2025.worker.BatchScheduler
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {

  private lateinit var b: ActivityMainBinding
  private lateinit var store: QueueStore
  private lateinit var adapter: QueueAdapter

  private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
    refresh()
  }

  private val pickVideos = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
    if (uris.isNullOrEmpty()) return@registerForActivityResult

    val settings = SettingsStore.load(this)

    val items = uris.map { uri ->
      SafUtils.persistRead(this, uri)
      val name = SafUtils.displayName(this, uri)
      val inputBytes = SafUtils.sizeBytes(this, uri)
      val meta = SafUtils.meta(this, uri)
      val targetBytes = CompressionPlanner.targetBytes(inputBytes, settings.targetRatio)

      QueueItem(
        id = UUID.randomUUID().toString(),
        uri = uri.toString(),
        name = name,
        inputBytes = inputBytes,
        targetBytes = targetBytes,
        state = ItemState.QUEUED,
        progress = 0,
        outputPath = null,
        outputBytes = 0L,
        error = null
      )
    }

    store.add(items)
    BatchScheduler.enqueueSequential(this, items)
  }

  private val requestNotifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    b = ActivityMainBinding.inflate(layoutInflater)
    setContentView(b.root)

    setSupportActionBar(b.toolbar)

    store = QueueStore(this)
    adapter = QueueAdapter(
      onOpen = { openOutput(it) },
      onShare = { shareOutput(it) },
      onRetry = { retryItem(it) }
    )
    b.recycler.adapter = adapter

    b.toolbar.setOnMenuItemClickListener { onMenu(it) }

    b.fab.setOnClickListener {
      maybeRequestNotifications()
      pickVideos.launch(arrayOf("video/*"))
    }

    store.registerListener(prefListener)
    refresh()
  }

  override fun onDestroy() {
    super.onDestroy()
    store.unregisterListener(prefListener)
  }

  private fun onMenu(item: MenuItem): Boolean {
    return when (item.itemId) {
      R.id.action_settings -> {
        openSettings()
        true
      }
      R.id.action_cancel -> {
        BatchScheduler.cancelAll(this)
        Snackbar.make(b.root, "صف متوقف شد", Snackbar.LENGTH_LONG).show()
        true
      }
      R.id.action_clear -> {
        store.clearFinished()
        Snackbar.make(b.root, "آیتم‌های تمام‌شده پاک شدند", Snackbar.LENGTH_LONG).show()
        true
      }
      else -> false
    }
  }

  private fun refresh() {
    val items = store.load()
    b.emptyState.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    adapter.submitList(items)

    if (items.isEmpty()) {
      b.batchSubtitle.text = "—"
      b.batchProgress.setProgressCompat(0, true)
      return
    }

    val avg = (items.sumOf { it.progress.coerceIn(0,100) }.toDouble() / items.size).toInt().coerceIn(0,100)
    val done = items.count { it.state == ItemState.DONE || it.state == ItemState.FAILED }
    val running = items.count { it.state == ItemState.RUNNING }
    val queued = items.count { it.state == ItemState.QUEUED }

    b.batchProgress.setProgressCompat(avg, true)
    b.batchSubtitle.text = "Total " + Formatters.pct(avg) + " • " + done + "/" + items.size + " done • " + running + " running • " + queued + " queued"
  }

  private fun openOutput(item: QueueItem) {
    val path = item.outputPath ?: return
    val file = File(path)
    if (!file.exists()) {
      Snackbar.make(b.root, "فایل خروجی پیدا نشد", Snackbar.LENGTH_LONG).show()
      return
    }
    val uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
      setDataAndType(uri, "video/*")
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { startActivity(intent) }
      .onFailure { Snackbar.make(b.root, "برنامه‌ای برای باز کردن ویدیو پیدا نشد", Snackbar.LENGTH_LONG).show() }
  }

  private fun shareOutput(item: QueueItem) {
    val path = item.outputPath ?: return
    val file = File(path)
    if (!file.exists()) {
      Snackbar.make(b.root, "فایل خروجی پیدا نشد", Snackbar.LENGTH_LONG).show()
      return
    }
    val uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".fileprovider", file)
    val share = Intent(Intent.ACTION_SEND).apply {
      type = "video/*"
      putExtra(Intent.EXTRA_STREAM, uri)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    startActivity(Intent.createChooser(share, "Share"))
  }

  private fun retryItem(item: QueueItem) {
    store.resetToQueued(item.id)
    BatchScheduler.enqueueSequential(this, listOf(item.copy(state = ItemState.QUEUED, progress = 0, outputPath = null, outputBytes = 0L, error = null)))
    Snackbar.make(b.root, "در صف قرار گرفت", Snackbar.LENGTH_LONG).show()
  }

  private fun openSettings() {
    val cur = SettingsStore.load(this)

    val options = arrayOf(
      "Pro (95% کاهش) – پیشنهاد",
      "Balanced (90% کاهش)",
      "Ultra (80% کاهش)"
    )
    val ratios = doubleArrayOf(0.05, 0.10, 0.20)

    var selected = ratios.indexOfFirst { kotlin.math.abs(it - cur.targetRatio) < 0.0001 }.coerceAtLeast(0)
    var keep1080 = cur.prefer1080p

    val view = layoutInflater.inflate(android.R.layout.select_dialog_item, null)

    val builder = AlertDialog.Builder(this)
      .setTitle("تنظیمات کیفیت")
      .setSingleChoiceItems(options, selected) { _, which -> selected = which }
      .setMultiChoiceItems(arrayOf("ترجیح 1080p (اگر ممکن باشد)"), booleanArrayOf(keep1080)) { _, _, isChecked ->
        keep1080 = isChecked
      }
      .setPositiveButton("ذخیره") { _, _ ->
        SettingsStore.save(this, cur.copy(targetRatio = ratios[selected], prefer1080p = keep1080))
        Snackbar.make(b.root, "ذخیره شد", Snackbar.LENGTH_LONG).show()
      }
      .setNegativeButton("بستن", null)

    builder.show()
  }

  private fun maybeRequestNotifications() {
    if (Build.VERSION.SDK_INT < 33) return
    val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    if (!granted) requestNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
  }
}
