package com.hyper.compressor2025.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.HandlerThread
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.AudioEncoderSettings
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.TransformationRequest
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.hyper.compressor2025.data.ItemState
import com.hyper.compressor2025.data.QueueStore
import com.hyper.compressor2025.domain.CompressionPlanner
import com.hyper.compressor2025.domain.SettingsStore
import com.hyper.compressor2025.util.SafUtils
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.math.max

class CompressWorker(
  appContext: Context,
  params: WorkerParameters
) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    ensureChannel()

    val itemId = inputData.getString(KEY_ITEM_ID) ?: return Result.failure()
    val uriStr = inputData.getString(KEY_URI) ?: return Result.failure()
    val name = inputData.getString(KEY_NAME) ?: "Video"

    val store = QueueStore(applicationContext)
    store.update(itemId, state = ItemState.RUNNING, progress = 0, error = null)

    val uri = Uri.parse(uriStr)
    val meta = SafUtils.meta(applicationContext, uri)
    val inputBytes = SafUtils.sizeBytes(applicationContext, uri)

    val settings = SettingsStore.load(applicationContext)
    val targetBytes = CompressionPlanner.targetBytes(inputBytes, settings.targetRatio)
    val chosenHeight = CompressionPlanner.chooseHeight(meta, targetBytes, settings.prefer1080p, settings.maxFpsAssumed)
    val videoBitrate = CompressionPlanner.videoBitrateBps(targetBytes, meta)

    if (meta.durationMs <= 0) {
      store.update(itemId, state = ItemState.FAILED, progress = 100, error = "فایل خراب یا غیرقابل خواندن")
      return Result.success()
    }

    val outFile = createOutputFile(name)

    val res = transcode(
      uri = uri,
      outputPath = outFile.absolutePath,
      maxHeight = chosenHeight,
      videoBitrate = videoBitrate,
      title = name,
      onProgress = { p ->
        store.update(itemId, progress = p)
        setForegroundAsync(makeFg(p, name))
      }
    )

    return if (res.success) {
      val outBytes = outFile.length().coerceAtLeast(0L)
      store.update(itemId, state = ItemState.DONE, progress = 100, outputPath = outFile.absolutePath, outputBytes = outBytes, error = null)
      Result.success()
    } else {
      store.update(itemId, state = ItemState.FAILED, progress = 100, error = res.error ?: "Unknown error")
      Result.success() // continue queue
    }
  }

  private data class OneResult(val success: Boolean, val error: String? = null)

  private fun pickVideoMime(): String {
    // Prefer AV1 if encoder exists, else HEVC, else H264
    fun hasEncoder(mime: String): Boolean {
      val list = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos
      return list.any { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, ignoreCase = true) } }
    }
    return when {
      hasEncoder(MimeTypes.VIDEO_AV1) -> MimeTypes.VIDEO_AV1
      hasEncoder(MimeTypes.VIDEO_H265) -> MimeTypes.VIDEO_H265
      else -> MimeTypes.VIDEO_H264
    }
  }

  private suspend fun transcode(
    uri: Uri,
    outputPath: String,
    maxHeight: Int,
    videoBitrate: Int,
    title: String,
    onProgress: (Int) -> Unit
  ): OneResult {
    val handlerThread = HandlerThread("Transformer").apply { start() }
    val completion = CompletableDeferred<OneResult>()

    val chosenVideoMime = pickVideoMime()

    val request = TransformationRequest.Builder()
      .setVideoMimeType(chosenVideoMime)
      .setAudioMimeType(MimeTypes.AUDIO_AAC)
      .build()

    val vSettings = VideoEncoderSettings.Builder()
      .setBitrate(videoBitrate)
      .setBitrateMode(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
      .setIFrameIntervalSeconds(2.0f)
      .build()

    val aSettings = AudioEncoderSettings.Builder()
      .setBitrate(96_000)
      .build()

    val encoderFactory = DefaultEncoderFactory.Builder(applicationContext)
      .setRequestedVideoEncoderSettings(vSettings)
      .setRequestedAudioEncoderSettings(aSettings)
      .setEnableFallback(true)
      .build()

    val effects = if (maxHeight > 0) {
      Effects(emptyList(), listOf(Presentation.createForHeight(maxHeight)))
    } else {
      Effects(emptyList(), emptyList())
    }

    val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
      .setEffects(effects)
      .build()

    val transformer = Transformer.Builder(applicationContext)
      .setTransformationRequest(request)
      .setEncoderFactory(encoderFactory)
      .setLooper(handlerThread.looper)
      .addListener(object : Transformer.Listener {
        override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
          completion.complete(OneResult(true))
        }
        override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
          val msg = "E${exportException.errorCode}: " + (exportException.message ?: "error")
          completion.complete(OneResult(false, msg))
        }
      })
      .build()

    try {
      setForegroundAsync(makeFg(0, title))
      transformer.start(edited, outputPath)

      val ph = ProgressHolder()
      var last = -1
      while (!completion.isCompleted && coroutineContext.isActive) {
        val state = transformer.getProgress(ph)
        if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
          val p = ph.progress.coerceIn(0, 100)
          if (p != last) {
            last = p
            onProgress(p)
            NotificationManagerCompat.from(applicationContext).notify(NOTIF_ID, notif(p, title))
          }
        }
        delay(250)
      }
      return completion.await()
    } catch (e: Throwable) {
      return OneResult(false, e.message ?: e.javaClass.simpleName)
    } finally {
      runCatching { transformer.cancel() }
      runCatching { handlerThread.quitSafely() }
    }
  }

  private fun ensureChannel() {
    if (Build.VERSION.SDK_INT < 26) return
    val mgr = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (mgr.getNotificationChannel(CHANNEL_ID) != null) return
    mgr.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Compression", NotificationManager.IMPORTANCE_LOW))
  }

  private fun notif(progress: Int, title: String) =
    NotificationCompat.Builder(applicationContext, CHANNEL_ID)
      .setSmallIcon(android.R.drawable.stat_sys_upload)
      .setContentTitle("HyperCompressor")
      .setContentText("Compressing • $title")
      .setOnlyAlertOnce(true)
      .setOngoing(true)
      .setProgress(100, progress.coerceIn(0, 100), false)
      .build()

  private fun makeFg(progress: Int, title: String): ForegroundInfo {
    val n = notif(progress, title)
    return if (Build.VERSION.SDK_INT >= 29) {
      ForegroundInfo(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
    } else {
      ForegroundInfo(NOTIF_ID, n)
    }
  }

  private fun createOutputFile(displayName: String): File {
    val safe = displayName.replace(Regex("[^a-zA-Z0-9._-]+"), "_").take(48).ifBlank { "video" }
    val dir = applicationContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: applicationContext.filesDir
    if (!dir.exists()) dir.mkdirs()
    return File(dir, "hyper_" + System.currentTimeMillis() + "_" + safe + ".mp4")
  }

  companion object {
    const val KEY_ITEM_ID = "item_id"
    const val KEY_URI = "uri"
    const val KEY_NAME = "name"

    private const val CHANNEL_ID = "hypercompress_channel"
    private const val NOTIF_ID = 1001
  }
}
