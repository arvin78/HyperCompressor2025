package com.hyper.compressor2025.ui

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.hyper.compressor2025.data.ItemState
import com.hyper.compressor2025.data.QueueItem
import com.hyper.compressor2025.databinding.ItemQueueBinding
import com.hyper.compressor2025.util.Formatters
import java.io.File

class QueueAdapter(
  private val onOpen: (QueueItem) -> Unit,
  private val onShare: (QueueItem) -> Unit,
  private val onRetry: (QueueItem) -> Unit
) : ListAdapter<QueueItem, QueueAdapter.VH>(DIFF) {

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
    val b = ItemQueueBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    return VH(b)
  }

  override fun onBindViewHolder(holder: VH, position: Int) {
    holder.bind(getItem(position), onOpen, onShare, onRetry)
  }

  class VH(private val b: ItemQueueBinding) : RecyclerView.ViewHolder(b.root) {
    fun bind(item: QueueItem, onOpen: (QueueItem) -> Unit, onShare: (QueueItem) -> Unit, onRetry: (QueueItem) -> Unit) {
      b.title.text = item.name

      val status = when (item.state) {
        ItemState.QUEUED -> b.root.context.getString(com.hyper.compressor2025.R.string.queued)
        ItemState.RUNNING -> b.root.context.getString(com.hyper.compressor2025.R.string.running)
        ItemState.DONE -> b.root.context.getString(com.hyper.compressor2025.R.string.done)
        ItemState.FAILED -> b.root.context.getString(com.hyper.compressor2025.R.string.failed)
      }
      b.statusChip.text = status

      val inSz = Formatters.bytes(item.inputBytes)
      val tgt = Formatters.bytes(item.targetBytes)
      val outSz = if (item.outputBytes > 0) Formatters.bytes(item.outputBytes) else "—"
      val err = item.error?.takeIf { it.isNotBlank() }

      b.subtitle.text = buildString {
        append("Input: "); append(inSz)
        append("  →  Target: "); append(tgt)
        append("  →  Out: "); append(outSz)
        err?.let {
          append("\n"); append(it)
        }
      }

      val p = item.progress.coerceIn(0, 100)
      b.progress.setProgressCompat(p, true)
      b.progressText.text = Formatters.pct(p)

      // Thumb: input uri while queued/running, output file when done
      val thumbModel: Any = if (item.state == ItemState.DONE && !item.outputPath.isNullOrBlank()) {
        File(item.outputPath)
      } else {
        Uri.parse(item.uri)
      }
      Glide.with(b.thumb).load(thumbModel).centerCrop().into(b.thumb)

      val canOpen = item.state == ItemState.DONE && !item.outputPath.isNullOrBlank()
      b.openButton.isEnabled = canOpen
      b.openButton.alpha = if (canOpen) 1f else 0.5f
      b.openButton.setOnClickListener { if (canOpen) onOpen(item) }

      b.shareButton.isEnabled = canOpen
      b.shareButton.alpha = if (canOpen) 1f else 0.5f
      b.shareButton.setOnClickListener { if (canOpen) onShare(item) }

      val canRetry = item.state == ItemState.FAILED
      b.retryButton.visibility = if (canRetry) View.VISIBLE else View.GONE
      b.retryButton.setOnClickListener { if (canRetry) onRetry(item) }
    }
  }

  companion object {
    private val DIFF = object : DiffUtil.ItemCallback<QueueItem>() {
      override fun areItemsTheSame(oldItem: QueueItem, newItem: QueueItem) = oldItem.id == newItem.id
      override fun areContentsTheSame(oldItem: QueueItem, newItem: QueueItem) = oldItem == newItem
    }
  }
}
