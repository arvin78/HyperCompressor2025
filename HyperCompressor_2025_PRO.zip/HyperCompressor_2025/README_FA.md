# HyperCompressor 2025 (PRO)

## ساخت APK فقط با گوشی (ZIP + Actions)
1) فایل ZIP پروژه را در ریشه ریپو آپلود کن.
2) فایل `.github/workflows/build.yml` را طبق متن چت بساز/آپدیت کن.
3) تب Actions → دانلود Artifact با نام `app-debug-apk`.

## خروجی‌ها
فایل خروجی داخل:
Android/data/<package>/files/Movies/
و داخل برنامه می‌تونی Open/Share بزنی.
